<?php
/**
 * Plugin Name: Odinokov Cyr-to-Lat Redirect
 * Plugin URI:  https://fahmann.ru
 * Description: Автоматический 301 редирект с URL, содержащих кириллические символы, на латинские аналоги (после транслитерации плагином Cyr-To-Lat).
 * Version:     1.0.1
 * Author:      Odinokov
 * Author URI:  https://fahmann.ru
 * License:     GPL-2.0+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'OCLR_VERSION', '1.0.1' );

require_once plugin_dir_path( __FILE__ ) . 'includes/class-oclr-updater.php';

new OCLR_Plugin_Updater(
    __FILE__,
    'https://fahmann.ru/wp-content/uploads/updates/odinokov-cyr-to-lat-rdr.json',
    OCLR_VERSION,
    array(
        'name'        => 'Odinokov Cyr-to-Lat Redirect',
        'author'      => '<a href="https://fahmann.ru">Odinokov</a>',
        'author_uri'  => 'https://fahmann.ru',
        'description' => 'Автоматический 301 редирект с URL, содержащих кириллические символы, на латинские аналоги.',
    )
);

add_action( 'admin_menu', 'oclr_admin_menu' );
function oclr_admin_menu() {
    global $menu; $e = false;
    if ( is_array( $menu ) ) { foreach ( $menu as $i ) { if ( isset( $i[2] ) && 'odinokov-plugins' === $i[2] ) { $e = true; break; } } }
    if ( ! $e ) add_menu_page( 'Одиноков', 'Одиноков', 'manage_options', 'odinokov-plugins', 'oclr_dashboard', 'dashicons-admin-settings', 30 );
    add_submenu_page( 'odinokov-plugins', 'Cyr-to-Lat Redirect', 'Cyr-to-Lat RDR', 'manage_options', 'odinokov-cyr-to-lat-rdr', 'oclr_dashboard' );
}

function oclr_dashboard() {
    ?>
    <div class="wrap"><h1>Плагины Одиноков</h1>
    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-top:20px;">
        <div style="background:#fff;border:1px solid #c3c4c7;border-radius:4px;padding:16px;">
            <h3 style="margin-top:0;">Odinokov Cyr-to-Lat Redirect</h3>
            <p>Автоматический 301 редирект с кириллических URL на латиницу. Работает автоматически, настроек не требует.</p>
            <p style="color:green;">Активно</p>
        </div>
    </div></div>
    <?php
}

class OCLR_Redirect {

    private static $cyr_to_lat_map = [
        'А'=>'A','Б'=>'B','В'=>'V','Г'=>'G','Д'=>'D','Е'=>'E','Ё'=>'YO','Ж'=>'ZH','З'=>'Z','И'=>'I','Й'=>'J','К'=>'K','Л'=>'L','М'=>'M','Н'=>'N','О'=>'O','П'=>'P','Р'=>'R','С'=>'S','Т'=>'T','У'=>'U','Ф'=>'F','Х'=>'H','Ц'=>'CZ','Ч'=>'CH','Ш'=>'SH','Щ'=>'SHH','Ъ'=>'','Ы'=>'Y','Ь'=>'','Э'=>'E','Ю'=>'YU','Я'=>'YA',
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'yo','ж'=>'zh','з'=>'z','и'=>'i','й'=>'j','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'h','ц'=>'cz','ч'=>'ch','ш'=>'sh','щ'=>'shh','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
        'І'=>'I','і'=>'i','Ѣ'=>'YE','ѣ'=>'ye','Ѳ'=>'FH','ѳ'=>'fh','Ѵ'=>'YH','ѵ'=>'yh',
    ];

    public static function init() {
        add_action( 'template_redirect', [ __CLASS__, 'do_redirect' ], 1 );
    }

    public static function do_redirect() {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) return;
        $uri = $_SERVER['REQUEST_URI'];
        $decoded = urldecode( $uri );
        $parsed = wp_parse_url( $decoded );
        $path = isset( $parsed['path'] ) ? $parsed['path'] : '';
        if ( ! self::contains_cyrillic( $path ) ) return;
        $new_path = self::transliterate( $path );
        if ( $new_path === $path ) return;
        $new_url = home_url( $new_path );
        if ( ! empty( $parsed['query'] ) ) $new_url .= '?' . $parsed['query'];
        wp_redirect( $new_url, 301 ); exit;
    }

    private static function contains_cyrillic( $s ) { return (bool) preg_match( '/[\x{0400}-\x{04FF}]/u', $s ); }
    private static function transliterate( $s ) { return strtr( $s, self::$cyr_to_lat_map ); }
}

OCLR_Redirect::init();
